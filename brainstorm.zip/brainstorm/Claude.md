# Claude.md - Jaunty Development Guidelines

## Project Overview

**Jaunty** is a lightweight, high-performance micro-ORM for .NET that executes SQL and maps results to objects with strict type safety. No query builders, no LINQ translation, no magic - just fast, predictable data access.

### Core Philosophy
- **Strict mapping by default** - All entity properties must have matching columns or an exception is thrown
- **Zero external dependencies** - Framework-only (except async interfaces for netstandard2.0)
- **Performance through compilation** - Expression trees compiled once, reused forever
- **Minimal allocations** - Only entity instances allocated per row

### Target Frameworks
- `netstandard2.0` - Broad compatibility
- `net8.0` - Modern .NET optimizations (FrozenDictionary, etc.)

---

## Project Structure

```
src/Jaunty/
├── PublicApi/           # External API surface
│   ├── Attributes/      # [Table], [Column], [Ignore], [Key]
│   ├── Configuration/   # JauntyConfig static class
│   ├── Interfaces/      # IMapped<T>, IEntity<T>
│   ├── Query*.cs        # Extension methods (sync)
│   ├── QueryAsync*.cs   # Extension methods (async)
│   ├── Execute*.cs      # Non-query execution
│   ├── CommandOptions.cs
│   └── GridReader.cs
│
├── InternalApi/         # Implementation details (internal visibility)
│   ├── Entity/          # Metadata, caching, reflection
│   ├── Parameters/      # SQL parsing, parameter binding
│   ├── QueryCore*.cs    # Core execution logic
│   ├── ExecuteReader*.cs
│   └── DrDispatcher.cs  # Mapper selection
│
└── Readers/
    └── EntityReader.cs  # Streaming enumeration

tests/Jaunty.Tests/
├── Integration/         # Database tests with SQLite
├── Unit/                # Isolated unit tests
├── Entities/            # Test models
└── Helpers/             # Database setup
```

---

## Coding Style & Conventions

### Naming

| Element | Convention | Example |
|---------|------------|---------|
| Namespaces | Hierarchical | `Jaunty.InternalApi.Entity` |
| Public classes | PascalCase | `GridReader`, `CommandOptions` |
| Internal classes | PascalCase + `internal sealed` | `internal sealed class EntityMetadata` |
| Methods | PascalCase, verb-based | `Query<T>()`, `CreateSetter()` |
| Properties | PascalCase, noun-based | `ColumnName`, `Mapper` |
| Parameters | camelCase | `sql`, `reader`, `columnName` |
| Private fields | _camelCase | `_cache`, `_columnNameResolver` |
| Generic type params | Single letter | `<T>`, `<TResult>` |

### File Organization

- **One public type per file**
- **Extension methods**: Use `partial class Jaunty` across multiple files
- **File naming**: Match the primary method name (`Query.cs`, `QueryPartial.cs`, `QueryAsync.cs`)
- **Visibility**: Use `internal` extensively for implementation details

### Code Patterns

**1. Extension Methods on IDbConnection**
```csharp
public static partial class Jaunty
{
    public static List<T> Query<T>(this IDbConnection connection, string sql) where T : new()
    {
        // Implementation
    }
}
```

**2. Static Generic Caching**
```csharp
internal static class MetadataCache<T> where T : new()
{
    static MetadataCache() { /* One-time initialization */ }
    public static readonly EntityMetadata Metadata;
}
```

**3. Expression Tree Compilation**
```csharp
private static Action<T, IDataRecord, int> CreateSetter(PropertyInfo property)
{
    var target = Expression.Parameter(typeof(T), "target");
    // Build and compile expression tree
    return Expression.Lambda<Action<T, IDataRecord, int>>(assign, ...).Compile();
}
```

**4. Dispatcher Pattern for Mapper Selection**
```csharp
// Priority: User override > IMapped<T> > Reflection fallback
if (options.Mapper is not null) return options.Mapper;
if (MappedCache<T>.Mapper is not null) return MappedCache<T>.Mapper;
// Fall back to reflection-based mapper
```

**5. Connection State Management**
```csharp
var wasClosed = connection.State == ConnectionState.Closed;
try
{
    if (wasClosed) connection.Open();
    // Execute
}
finally
{
    if (wasClosed && connection.State != ConnectionState.Closed)
        connection.Close();
}
```

**6. Readonly Structs with Primary Constructors (C# 12)**
```csharp
public readonly struct CommandOptions<T>(Func<IDataReader, T>? mapper = null, ...)
{
    public readonly Func<IDataReader, T>? Mapper = mapper;
}
```

**7. Conditional Compilation**
```csharp
#if NET8_0_OR_GREATER
    // Use FrozenDictionary
#else
    // Use Dictionary
#endif
```

### Type Constraints

- Use `where T : new()` for entities requiring parameterless constructors
- Keep generic variance minimal - most generics are invariant

---

## Testing Approach

### Framework
- **xUnit** for test framework
- **FluentAssertions** for assertions
- **SQLite** (Northwind sample) for integration tests

### Test Patterns

```csharp
public class QueryTests : IDisposable
{
    private readonly Database _db;

    public QueryTests() => _db = new Database();
    public void Dispose() => _db.Dispose();

    [Fact]
    public void Query_StrictMode_MissingColumn_Throws()
    {
        var ex = Assert.Throws<InvalidOperationException>(() =>
            _db.Connection.Query<Category>(sql));

        Assert.Contains("Description", ex.Message);
    }
}
```

### Test Organization
- **Integration/**: Database tests with actual queries
- **Unit/**: Isolated tests (parameter parsing, options)
- **Entities/**: Test models matching Northwind schema

---

## Key APIs

### Query Methods (all extend `IDbConnection`)

| Method | Returns | Mapping Mode |
|--------|---------|--------------|
| `Query<T>()` | `List<T>` | Strict |
| `QueryPartial<T>()` | `List<T>` | Partial |
| `QueryFirst<T>()` | `T` | Strict |
| `QueryFirstOrDefault<T>()` | `T?` | Strict |
| `QuerySingle<T>()` | `T` | Strict |
| `QuerySingleOrDefault<T>()` | `T?` | Strict |
| `QueryScalar<T>()` | `T` | N/A |
| `QueryStream<T>()` | `IEnumerable<T>` | Strict |
| `QueryMultiple()` | `GridReader` | N/A |

All have async counterparts (`QueryAsync<T>`, etc.).

### Parameter Binding
```csharp
// Named parameters
connection.Query<Product>(sql, new { CategoryId = 1 });

// Single positional
connection.Query<Product>(sql, 42);

// Multiple positional (parsed from SQL)
connection.Query<Product>(sql, 1, "active", 50.00m);
```

### CommandOptions
```csharp
// With custom mapper
connection.Query<Product>(sql, CommandOptions<Product>.WithMapper(MapProduct));

// With transaction
connection.Query<Product>(sql, CommandOptions<Product>.WithTransaction(tx));

// With timeout
connection.Query<Product>(sql, CommandOptions<Product>.WithTimeout(30));
```

---

## Instructions for Claude

<!-- PLACEHOLDER: Project-Specific Rules -->
### Project-Specific Rules
- [ ] <!-- Add specific rules about this project's conventions -->
- [ ] <!-- Add rules about dependencies or packages to avoid -->
- [ ] <!-- Add rules about specific patterns to follow or avoid -->

<!-- PLACEHOLDER: Feature Development Guidelines -->
### Feature Development Guidelines
- [ ] <!-- Add guidelines for implementing new query methods -->
- [ ] <!-- Add guidelines for adding new attributes -->
- [ ] <!-- Add guidelines for extending the configuration system -->

<!-- PLACEHOLDER: Performance Requirements -->
### Performance Requirements
- [ ] <!-- Add specific performance targets or constraints -->
- [ ] <!-- Add rules about allocation limits -->
- [ ] <!-- Add rules about caching requirements -->

<!-- PLACEHOLDER: API Design Principles -->
### API Design Principles
- [ ] <!-- Add rules about method naming for new APIs -->
- [ ] <!-- Add rules about parameter ordering conventions -->
- [ ] <!-- Add rules about overload patterns -->

<!-- PLACEHOLDER: Error Handling -->
### Error Handling
- [ ] <!-- Add rules about exception types to use -->
- [ ] <!-- Add rules about error message formatting -->
- [ ] <!-- Add rules about when to throw vs return null -->

<!-- PLACEHOLDER: Testing Requirements -->
### Testing Requirements
- [ ] <!-- Add minimum test coverage requirements -->
- [ ] <!-- Add rules about what must be tested -->
- [ ] <!-- Add rules about test naming conventions -->

<!-- PLACEHOLDER: Documentation -->
### Documentation Requirements
- [ ] <!-- Add rules about XML documentation -->
- [ ] <!-- Add rules about README updates -->
- [ ] <!-- Add rules about changelog entries -->

<!-- PLACEHOLDER: Git & PR Guidelines -->
### Git & PR Guidelines
- [ ] <!-- Add commit message format rules -->
- [ ] <!-- Add branch naming conventions -->
- [ ] <!-- Add PR template requirements -->

<!-- PLACEHOLDER: Security Considerations -->
### Security Considerations
- [ ] <!-- Add rules about SQL injection prevention -->
- [ ] <!-- Add rules about parameter validation -->
- [ ] <!-- Add rules about sensitive data handling -->

<!-- PLACEHOLDER: Breaking Changes -->
### Breaking Change Policy
- [ ] <!-- Add rules about when breaking changes are acceptable -->
- [ ] <!-- Add rules about deprecation process -->
- [ ] <!-- Add rules about version bumping -->

---

## Anti-Patterns to Avoid

1. **No LINQ in hot paths** - Allocations hurt performance
2. **No reflection during query execution** - Use compiled delegates
3. **No silent partial mapping** - Always explicit via `QueryPartial<T>()`
4. **No external dependencies** - Keep the library lightweight
5. **No query builders** - SQL is explicit and transparent
6. **No magic string manipulation** - Parse SQL properly with state machine

---

## Common Tasks

### Adding a New Query Method
1. Create file in `PublicApi/` named after method
2. Add as extension method on `IDbConnection` in `partial class Jaunty`
3. Add `where T : new()` constraint if entity instantiation required
4. Use `QueryCore` or `QueryCoreAsync` for execution
5. Add async variant in corresponding `*Async.cs` file
6. Add integration tests in `tests/Jaunty.Tests/Integration/`

### Adding a New Attribute
1. Create in `PublicApi/Attributes/`
2. Use `AttributeTargets.Property` or `AttributeTargets.Class`
3. Update `MetadataBuilder.cs` to read the attribute
4. Add tests for attribute resolution
5. Document priority relative to `JauntyConfig` resolvers

### Modifying Parameter Binding
1. Update `SqlParameterParser.cs` for parsing changes
2. Update `ParameterBinder.cs` for binding changes
3. Ensure state machine handles edge cases (comments, strings, quotes)
4. Add comprehensive unit tests in `SqlParameterParserTests.cs`

## C# Performance and Memory Optimization
1. Memory and Allocation

- Span<T> and ReadOnlySpan<T>: Use for zero-allocation slicing of arrays, strings, and unmanaged memory buffers.
- ValueTask and ValueTask<T>: Use for asynchronous methods that frequently complete synchronously to avoid heap-allocating Task objects.
- ArrayPool<T>.Shared: Use to rent and return large arrays, significantly reducing Garbage Collector (GC) pressure in high-throughput applications.
- stackalloc: Allocate small, fixed-size buffers on the stack to bypass the managed heap entirely.
- readonly struct: Prevents the compiler from creating hidden defensive copies when passing structures or accessing their members.
- GC.AllocateUninitializedArray<T>: Use for high-performance array creation when you intend to overwrite the entire array immediately, skipping the zeroing phase.
- NativeMemory: Use for explicit, manual memory allocation outside of the managed heap for interop or extreme performance scenarios.
- Avoid boxing and unboxing: Use generic type parameters and constraints to keep value types on the stack.

2. Collections and Lookups

- Collection Capacity Pre-sizing: Always initialize List<T>, Dictionary<TKey, TValue>, and HashSet<T> with a known capacity to prevent expensive resizing and re-hashing operations.
- FrozenDictionary<TKey, TValue> and FrozenSet<T>: Use for immutable collections where lookup speed is the primary bottleneck.
- SearchValues<T>: Use for highly optimized searching and filtering of characters or bytes within strings and spans.
- CollectionsMarshal.AsSpan<T>(List<T>): Access the underlying backing array of a List<T> as a span to avoid indexer overhead.
- string.Create: Construct strings by writing directly into their memory buffer, eliminating intermediate allocations and copies.
- Loops: Prefer traditional for loops over foreach when iterating collections to avoid enumerator allocations.

3. Execution and JIT Optimization

- SIMD (Single Instruction, Multiple Data): Leverage Vector<T> and System.Runtime.Intrinsics to process multiple data points in a single CPU cycle.
- MethodImplOptions.AggressiveInlining: Direct the JIT compiler to inline small, frequently called methods to eliminate call-stack overhead.
- System.Text.Json Source Generators: Replace reflection-based serialization with compile-time generated code for higher throughput and lower memory usage.
- StringComparison.Ordinal / OrdinalIgnoreCase: Use for the fastest possible string comparisons by bypassing culture-aware linguistic rules.
- ConfigureAwait(false): Prevent the capture of the SynchronizationContext in library code to reduce overhead and avoid deadlocks.
- Interlocked Operations: Use for atomic manipulation of primitives (increment, decrement, exchange) instead of heavyweight lock statements.
- Manual for loops over LINQ: Replace LINQ queries in "hot paths" with manual loops to avoid delegate allocations and enumerator overhead.
- Unsafe Class: Use for low-level pointer-like performance and memory manipulation when safety can be manually guaranteed
- Avoid exceptions in hot paths: Use Try-patterns (e.g., TryParse) to prevent the overhead of exception handling during normal execution flow.
- Avoid reflections: If you must use reflection, then cache the result so reflection only happens once.