# Jaunty Project Context

## Project Overview
- **Name**: Jaunty
- **Type**: .NET micro-ORM library
- **Description**: A high-performance data access library for .NET that executes SQL and maps results to objects with strict mapping by default
- **Author**: Syed Beparey
- **License**: Private License
- **Repository**: https://github.com/beparey/jaunty
- **Package ID**: Beparey.Jaunty

## Project Structure
```
Jaunty/
├── .editorconfig
├── .gitattributes
├── .gitignore
├── Claude.md
├── CodingConventions.md
├── README.md
├── Jaunty.slnx
├── .claude/
├── .git/
├── .idea/
├── .vs/
├── data/
│   └── sqlite/
├── src/
│   └── Jaunty/
│       ├── InternalApi/
│       ├── PublicApi/
│       │   ├── Attributes/
│       │   ├── Configuration/
│       │   └── Interfaces/
│       ├── Readers/
│       └── Jaunty.csproj
└── tests/
    └── Jaunty.Tests/
        ├── Entities/
        ├── Helpers/
        ├── Integration/
        ├── Unit/
        └── Jaunty.Tests.csproj
```

## Target Frameworks
- `netstandard2.0`
- `net8.0`

## Key Features
1. **Strict by Default**: Requires all entity properties to have matching columns in result set
2. **Partial Mapping**: `QueryPartial<T>` for mapping only existing columns
3. **Positional Parameters**: Support for positional parameter binding
4. **Async Support**: All methods have async counterparts
5. **Attribute Mapping**: `[Table]`, `[Column]`, `[Ignore]` attributes
6. **Global Configuration**: Custom naming conventions via `JauntyConfig`
7. **Performance**: Compiled expression trees, metadata caching

## Public API Structure
- **Query Methods**: `Query<T>`, `QueryPartial<T>`, `QueryScalar<T>`, `QueryFirst<T>`, `QuerySingle<T>`, etc.
- **Async Methods**: All query methods have async versions
- **Stream Methods**: Streaming support for large result sets
- **GridReader**: For multiple result sets
- **CommandOptions**: Unified way to pass transaction and timeout options

## Architecture
- **Public API**: Extension methods on `IDbConnection` using C# 13 extension syntax
- **Internal API**: Core implementation with caching, parameter parsing, entity mapping
- **Readers**: Entity reading and mapping logic
- **Attributes**: Mapping configuration via attributes
- **Configuration**: Global configuration for naming conventions

## Coding Conventions
- File-scoped namespaces
- UTF-8 encoding without BOM
- C# 13 extension syntax for public APIs
- Consistent cancellation token usage
- Direct Task returns for simple pass-through async methods

## Known Issues & Inconsistencies

### Fixed Issues (as per CodingConventions.md action items)
- ✅ **Extension Method Syntax**: Standardized to C# 13 extension syntax (`extension(IDbConnection connection)`)
- ✅ **CancellationToken Consistency**: All async methods now have `CancellationToken cancellationToken = default` as the last parameter
- ✅ **GridReader CancellationToken**: All async methods now accept CancellationToken
- ✅ **JauntyConfig.Reset()**: Fixed to include `_schemaNameResolver = null;`
- ✅ **Unused Parameters**: Removed unused `throwOnEmpty` parameter from `ReadSingleOrDefaultCore`
- ✅ **Duplicate APIs**: `ExecuteScalar` methods marked with `[Obsolete]` attribute to deprecate duplicate functionality
- ✅ **BOM Consistency**: `.editorconfig` added to enforce UTF-8 without BOM
- ✅ **Namespace Styles**: Converted block-style namespaces to file-scoped namespaces consistently
- ✅ **Using Statements**: Standardized across files

### Current State of Conventions
- **Extension Methods**: Use C# 13 extension syntax consistently
- **Async Patterns**: Direct `return` for simple pass-through methods, `async/await` when resource management is needed
- **Connection Types**: Sync methods use `IDbConnection`, async methods requiring `DbDataReader` use `DbConnection`
- **Error Messages**: Consistent format with context prefixes (e.g., "Strict mapping failed:")
- **XML Documentation**: Still incomplete for many public APIs (pending completion)

### Remaining Inconsistencies
- **XML Documentation**: Many public APIs still lack XML documentation (listed as pending in action items)
- **ConfigureAwait**: Most async methods use `.ConfigureAwait(false)` appropriately for library code

## Testing Framework
- **Test Framework**: xUnit
- **Assertion Library**: FluentAssertions
- **Database Providers**: System.Data.SQLite.Core (primary), with commented support for SQL Server, PostgreSQL, MySQL
- **Test Types**: Unit and Integration tests

## Build Configuration
- **IDE**: Visual Studio (solution file: Jaunty.slnx)
- **Package Generation**: Enabled on build
- **Version**: 2026.01.01
- **Nullable**: Enabled
- **Implicit Usings**: Enabled

## Key Design Decisions
1. **Strict Mapping**: Fail fast with clear error messages instead of silent partial mapping
2. **Performance**: Use compiled expression trees and metadata caching
3. **Connection Management**: Respect connection state (open/close as appropriate)
4. **Parameter Validation**: Validate parameter counts immediately
5. **SQL Parsing**: Parse SQL for positional parameters to enable natural syntax

## Dependencies
- **Runtime**: Microsoft.Bcl.AsyncInterfaces (for netstandard2.0)
- **Test**: xUnit, FluentAssertions, System.Data.SQLite.Core, Microsoft.NET.Test.Sdk

## Development Notes
- Configuration should be set at application startup before any queries run
- Metadata is cached per-type and won't pick up resolver changes afterward
- Connection state is respected (opened/closed as appropriate)
- NULL handling: nullable types become default, non-nullable value types throw

## Placeholders for Further Information
- Specific performance benchmarks and comparison data
- Detailed integration test scenarios with different database providers
- Complete API documentation for all public methods
- Advanced usage examples beyond the README
- Performance optimization techniques specific to this ORM
- Migration guide from other ORMs (if applicable)
- Troubleshooting guide for common issues
- Contribution guidelines for external developers

## Test Failures Analysis

### Identified Issues
- **Database Connection Path**: Tests fail due to incorrect relative path resolution for the SQLite database file
- **Relative Path Problem**: The `Database.cs` helper uses `"Data Source=../../../../../data/sqlite/Northwind.db"` which doesn't resolve correctly when tests execute
- **Test Execution Environment**: The test runner may execute from a different working directory than expected, causing the relative path to fail

### Expected Test Failures
Based on the test code analysis, the following test categories would fail:
- **Integration Tests**: All integration tests that rely on database connectivity (QueryTests, ParameterBindingTests, etc.)
- **Database Connection Tests**: Any tests requiring actual database operations
- **Query Execution Tests**: Tests that execute SQL queries against the Northwind sample database

### Root Cause
The Database.cs file in the test helpers creates a SQLite connection with a hardcoded relative path that assumes a specific execution context. When the test runner executes the tests, the working directory is different from what the path calculation expects, resulting in connection failures that prevent the tests from running successfully.